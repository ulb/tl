#include <vector>
#include <cstring> // std::equal
#include <algorithm> // std::find

#include "my_base_lib.h"

void slack_matrix_free_sum(int ** P,int ** Q,const int m1,const int n1,const int m2,const int n2,int **& P_oplus_Q,int & num_rows,int & num_cols) {
    int i,j,k;
    int offset;
    num_rows = m1 * m2;
    num_cols = n1 + n2;
    
    alloc(P_oplus_Q,num_rows,int*);
    for (i = 0; i < num_rows; ++i) alloc(P_oplus_Q[i],num_cols,int);
    
    offset = 0;
    for (i = 0; i < m2; ++i) {
        for (j = 0; j < m1; ++j)
            for (k = 0; k < n1; ++k) P_oplus_Q[j + offset][k] = P[j][k];
        offset += m1;
    }
    
    offset = 0;
    for (j = 0; j < m2; ++j) {
        for (i = 0; i < m1; ++i) {
            for (k = 0; k < n2; ++k) P_oplus_Q[offset][n1 + k] = Q[j][k];
            offset += 1;
        }
    }
}

void slack_matrix_simplicial_2L(const int h, const int n, int **& M, int & num_r_M, int & num_c_M) {
    int i,j;
    int ** Id;
    alloc(Id,h+1,int*);
    for (i = 0; i < h+1; ++i) alloc(Id[i],h+1,int);
    
    generate_id_matrix(h+1,Id); // Id(k+1) is the slack matrix of the k-simplex Delta_k
    
    num_r_M = h+1;
    num_c_M = h+1;
    alloc(M,num_r_M,int*);
    for (i = 0; i < num_r_M; ++i) {
        alloc(M[i],num_c_M,int);
        std::memcpy(M[i],Id[i],num_c_M * sizeof(int));
    }
    
    int ** M_oplus;
    int num_r_M_oplus,num_c_M_oplus;
    
    for (i = 0; i < n-1; ++i) {
        slack_matrix_free_sum(M,Id,num_r_M,num_c_M,h+1,h+1,M_oplus,num_r_M_oplus,num_c_M_oplus);
        for (j = 0; j < num_r_M; ++j) free(M[j]);
        free(M);
        M = M_oplus;
        num_r_M = num_r_M_oplus;
        num_c_M = num_c_M_oplus;
    }
    
    for (i = 0; i < h+1; ++i) free(Id[i]);
    free(Id);
}

void push_simplicial_core(int **& M,const int num_rows_M,const int num_cols_M,int **& Id,const int D) {
    int i,j,k;
    bool accept;
    // rearrange the columns in such a way that the first row begins with [1,0,...,0,...] (D zeros)
    // remember that every row has precisely D zeros and D ones since it is the slack matrix of a simplicial 2-level polytope
    int * temp_col;
    alloc(temp_col,num_rows_M,int);
    bool found = false;
    if (M[0][0] != 1) {
        for (j = 1; j < num_cols_M && !found; ++j) {
            if (M[0][j] == 1) {
                found = true;
                for (i = 0; i < num_rows_M; ++i) {
                    temp_col[i] = M[i][j];
                    M[i][j] = M[i][0];
                    M[i][0] = temp_col[i];
                }
            }
        }
    }
    for (k = 1; k < D+1; ++k) {
        found = false;
        if (M[0][k] != 0) {
            for (j = k+1; j < num_cols_M && !found; ++j) {
                if (M[0][j] == 0) {
                    found = true;
                    for (i = 0; i < num_rows_M; ++i) {
                        temp_col[i] = M[i][j];
                        M[i][j] = M[i][k];
                        M[i][k] = temp_col[i];
                    }
                }
            }
        }
    }
    free(temp_col);
    
    // rearranging rows of M
    int * temp_row;
    alloc(temp_row,num_cols_M,int);
    int temp_idx = 0;
    for (i = temp_idx+1; i < num_rows_M && temp_idx < D; ++i) {
        accept = true;
        for (j = 0; j < D && accept; ++j) accept = (M[i][j+1] == Id[temp_idx][j]);
        
        if (accept) {
            std::memcpy(temp_row,M[i],num_cols_M * sizeof(int));
            std::memcpy(M[i],M[temp_idx+1],num_cols_M * sizeof(int));
            std::memcpy(M[temp_idx+1],temp_row,num_cols_M * sizeof(int));
            temp_idx++;
        }
    }
    free(temp_row);
}