#ifndef CLOSURE_OPERATORS_H
#define CLOSURE_OPERATORS_H
 
bool is_preccurlyeq(int * A, int * B, const int length);

bool is_subseteq(int * A, int * B, const int length);

int min_A_idx(int * A, const int length);
bool is_sqsubseteq(int * A, int * B, const int length);
void inc(int* A, const int i, int* I, const int length);

void discreteconvexhull_cl(int *& A,int *& B,int *& dchcl,int **& slab_points_sat, const int length_A, const int length_B);

bool is_incompatible(int * A,int ** incompatibility_adjM,const int length_A);
void incompatibility_cl(int * A,int * inccl,int ** incompatibility_adjM,const int length_A);

void lexmax_symmetric(int *& A,int *& symcl,int **& ground_set_H,const int length_A,int ***& orbits,const int num_autom_base,const int D);

#endif