#include <vector>
#include <cstring> // std::equal
#include <algorithm> // std::find

#include <my_base_lib.h>

// Check if A \preccurlyeq B
bool is_preccurlyeq(int * A, int * B, const int length) {
    if (is_equal(A,B,length)) return true;
    int i = length - 1;
    while (i > 0) {
        if (((A[i] == 1) && (B[i] == 0)) || ((A[i] == 0) && (B[i] == 1))) return B[i] == 1;
        i--;
    }
    return B[0] == 1;
}

// Check if A is a subset of B
bool is_subseteq(int * A, int * B, const int length) {
    for (int i = 0; i < length; ++i) if (A[i] == 1 && B[i] == 0) return false;
    return true;
}

int min_A_idx(int * A, const int length) {
    for (int i = 0; i < length; ++i) if (A[i] == 1) return i;
    return length;
}

// Check if A \sqsubseteq B
bool is_sqsubseteq(int * A, int * B, const int length) {
    int min_A = min_A_idx(A,length);
    if (is_subseteq(A,B,length)) return is_equal(B+min_A,A+min_A,length-min_A);
    else return false;
}

// I = inc(A,i)
void inc(int* A, const int i, int* I, const int length) {
    std::memset(I,0,i * sizeof(int));
    I[i] = 1;
    std::memcpy(I+i+1, A+i+1,(length-i-1) * sizeof(int));
}

// Compute the discrete convex hull of a point set A
void discreteconvexhull_cl(int *& A,int *& B,int *& dchcl,int **& slab_points_sat, const int length_A, const int length_B) {
    int i, j;
    
    // Set all bits of B to 1
    std::fill(B,B+length_B,1);
    
    // Intersect all sets of slabs belonging to elements of A
    for (i = 0; i < length_A; ++i) {
        if (A[i] == 1) {
            for (j = 0; j < length_B; ++j)
                if (slab_points_sat[i][j] == 0)  B[j] = 0;
        }
    }    
    // Set all bits of dchcl to 1
    std::fill(dchcl,dchcl+length_A,1);
    
    // Intersect all sets of points belonging to elements of B
    for (i = 0; i < length_B; ++i) {
        if (B[i] == 1) {
            for (j = 0; j < length_A; ++j)
                if (slab_points_sat[j][i] == 0) dchcl[j] = 0;
        }
    }
}

// test for incompatibility
bool is_incompatible(int * A,int ** incompatibility_adjM,const int length_A) {
    for (int i = 0; i < length_A; ++i) {
        if (A[i] == 0) continue;
        for (int j = 0; j < i; ++j) if (A[j] == 1 && incompatibility_adjM[i][j] == 1) return false;
    }
    return true;
}

// incompatibility closure operator
void incompatibility_cl(int * A,int * inccl,int ** incompatibility_adjM,const int length_A) { 
    if (is_incompatible(A,incompatibility_adjM,length_A))
        std::memcpy(inccl,A,length_A * sizeof(int));
    else std::fill(inccl,inccl+length_A,1);
}

void lexmax_symmetric(int *& A,int *& symcl,int **& ground_set_H,const int length_A,int ***& orbits,const int num_autom_base,const int D) {
    int i,j;
    
    std::memcpy(symcl,A,length_A * sizeof(int));
    
    if (!(is_all_ones(A,length_A))) {
        bool is_outside_X;
        int * A_sym;
        alloc(A_sym,length_A,int);
        
        A_sym[0] = 1;
        std::memset(A_sym+1,0,(length_A-1) * sizeof(int));
        
        if (!is_equal(A,A_sym,length_A)) {
            for (i = 0; i < num_autom_base; ++i) {
                std::memset(A_sym+1,0,(length_A-1) * sizeof(int));
                is_outside_X = false;
                for (j = 1; j < length_A && !(is_outside_X); ++j) {
                    if (A[j] == 1) {
                        if (orbits[j][i][0] == 0) is_outside_X = true;
                        else A_sym[index_in_collection(ground_set_H,orbits[j][i],length_A,D)] = 1;
                    }
                }
                if (!(is_outside_X)) {
                    if (is_preccurlyeq(symcl,A_sym,length_A))
                        std::memcpy(symcl,A_sym,length_A * sizeof(int));
                }
            }
        }
        else std::memcpy(symcl,A_sym,length_A * sizeof(int));
        free(A_sym);
    }
}
