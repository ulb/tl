#include <nauty.h>

#include <vector>
#include <cstring>

#include "my_base_lib.h"

void canonicize(int ** S,const int num_rows,const int num_cols, const int n, const int m, setword * cg_vec) {
    // Initializations for Nauty
    DYNALLSTAT(int,lab,lab_sz);
    DYNALLSTAT(int,ptn,ptn_sz);
    DYNALLSTAT(int,orbits,orbits_sz);
    DYNALLSTAT(int,map,map_sz);
    DYNALLSTAT(graph,g,g_sz);
    DYNALLSTAT(graph,cg,cg_sz);
    static DEFAULTOPTIONS_GRAPH(options);
    statsblk stats;
    
    // Select option for canonical labelling
    options.getcanon = TRUE;
    
    // Select option for custom partition
    options.defaultptn = FALSE;
    
    nauty_check(WORDSIZE,m,n,NAUTYVERSIONID);
    
    // Allocate memory for the graph
    DYNALLOC1(int,lab,lab_sz,n,"malloc");
    DYNALLOC1(int,ptn,ptn_sz,n,"malloc");
    DYNALLOC1(int,orbits,orbits_sz,n,"malloc");
    DYNALLOC1(int,map,map_sz,n,"malloc");
    DYNALLOC2(graph,g,g_sz,n,m,"malloc");
    DYNALLOC2(graph,cg,cg_sz,n,m,"malloc");
    
    // Empty the graph
    EMPTYGRAPH(g,m,n);
    
    // Build the custom partition for the graph
    for (int i = 0; i < num_rows+num_cols; ++i) {
        lab[i] = i;
        if (i != num_rows-1 && i != num_rows+num_cols-1)
            ptn[i] = 1;
        else ptn[i] = 0;
    }
    
    // Build the edges of the nonincidence graph
    // Loop through all the entries of the slack matrix and add an edge when there is a one
    for (int i = 0; i < num_rows; ++i) {
        for (int j = 0; j < num_cols; ++j)
            if (S[i][j] == 1) ADDONEEDGE(g,i,j+num_rows,m);
    }
    
    // Obtain canonical graph from Nauty
    densenauty(g,lab,ptn,orbits,&options,&stats,m,n,cg);
    
    for (size_t k = 0; k < m*n; ++k) cg_vec[k] = cg[k];
    
    // Clean up
    DYNFREE(lab,lab_sz);
    DYNFREE(ptn,ptn_sz);
    DYNFREE(orbits,orbits_sz);
    DYNFREE(map,map_sz);
    DYNFREE(g,g_sz);
    DYNFREE(cg,cg_sz);
}

bool is_listed(setword ** list_2L,int * list_hash,const int list_length,setword * canonical_S,const int hash_S,const int length_canonical_S) {
    for (int i = 0; i < list_length; ++i) {
        if (hash_S == list_hash[i]) 
            if (is_equal(canonical_S,list_2L[i],length_canonical_S)) return true;
    }
    return false;
}

// Checks whether a given 0-1 matrix is the slack matrix of a D-dimensional 2-level polytope,
// by using the list of (D-1)-dimensional 2-level polytopes.
bool istwolevelpolytope(int ** S_new,const int num_rows_S_new,const int num_cols_S_new,int * atoms_hash,setword ** atoms_cg,const int n_atoms, const int D) {
    int i, j, k, h, l;
    // First test: check that every column contains at least D zeros
    // by construction, every row of S contains at least D zeros
    int num_facets_contain;
    for (j = 0; j < num_cols_S_new; ++j) {
        num_facets_contain = 0;
        for (i = 0; i < num_rows_S_new; ++i) if (S_new[i][j] == 0) num_facets_contain += 1;
        if (num_facets_contain < D) return false;
    }
    
    int ** zero_indices;
    int * num_zero_indices;
    alloc(zero_indices,num_rows_S_new,int*);
    alloc(num_zero_indices,num_rows_S_new,int);
    
    for (i = 0; i < num_rows_S_new; ++i) {
        k = 0;
        alloc(zero_indices[i],num_cols_S_new,int);
        zero_indices[i][0] = 0;
        for (j = 0; j < num_cols_S_new; ++j){
            if (S_new[i][j] == 0) {
                zero_indices[i][k] = j;
                ++k;
            }
        }
        num_zero_indices[i] = k;
    }
    
    int ** rows_S_Fi;
    int * num_rows_S_Fi;
    alloc(rows_S_Fi,num_rows_S_new,int*);
    alloc(num_rows_S_Fi,num_rows_S_new,int);
    
    bool is_maximal, is_subset;
    for (i = 0; i < num_rows_S_new; ++i) {
        alloc(rows_S_Fi[i],num_rows_S_new,int);
        l = 0; // current number of rows of S_Fi
        for (j = 0; j < num_rows_S_new; ++j) {
            if (j != i) {
                // the only rows in S_Fi are the one containing the maximal sets of zeros
                is_maximal = true;
                for (k = 0; k < num_rows_S_new && is_maximal; ++k) {
                    if ((k != j) && (k != i)) {
                        // Check if the set of zeros of S_new[j][.] intersected with the one of S_new[i][.]
                        // is a subset of the one S_new[k][.] intersected with the one of S_new[i][.]
                        is_subset = true;
                        for (h = 0; h < num_zero_indices[i] && is_subset; ++h) {
                            if (is_in_array(zero_indices[j],zero_indices[i][h],num_zero_indices[j]))
                                is_subset = is_in_array(zero_indices[k],zero_indices[i][h],num_zero_indices[k]);
                        }
                        is_maximal = !is_subset;
                    }
                }
                if (is_maximal) {
                    rows_S_Fi[i][l] = j;
                    ++l;
                }
            }
        }
        num_rows_S_Fi[i] = l;
    }
    
    // Go through all the rows and build the corresponding submatrix for each of them. If the input is a slack matrix,
    // this will compute the slack matrix of the corresponding facet and test is it appears in the list L_{D-1}
    int ** S_Fi;
    bool found = true;
    int n,m;

    for (i = 0; i < num_rows_S_new && found; ++i) {
        alloc(S_Fi,num_rows_S_Fi[i],int *);
        for (j = 0; j < num_rows_S_Fi[i]; ++j) {
            alloc(S_Fi[j],num_zero_indices[i],int);
            for (k = 0; k < num_zero_indices[i]; ++k)
                S_Fi[j][k] = S_new[rows_S_Fi[i][j]][zero_indices[i][k]];
        }
        
        setword * canonical_S_Fi;
        n = num_rows_S_Fi[i] + num_zero_indices[i];
        m = SETWORDSNEEDED(n);
        alloc(canonical_S_Fi,m*n,setword);
        canonicize(S_Fi,num_rows_S_Fi[i],num_zero_indices[i],n,m,canonical_S_Fi);
        int hash_S_Fi = ((num_zero_indices[i]-1) << D) + num_rows_S_Fi[i] - 1;
        
        found = is_listed(atoms_cg,atoms_hash,n_atoms,canonical_S_Fi,hash_S_Fi,m*n);

        // found = false;
        // for (it = 0; it < n_atoms && !found; it++) {
        //     hash2size(atoms_hash[it],num_rows_atom,num_cols_atom,D);
        //     if ((num_rows_S_Fi[i] == num_rows_atom) && (num_zero_indices[i] == num_cols_atom))
        //         found = is_equal(canonical_S_Fi,atoms_cg[it],m*n);
        // }
        
        free(canonical_S_Fi);
        for (j = 0; j < num_rows_S_Fi[i]; ++j) free(S_Fi[j]);
        free(S_Fi);
    }
    
    for (i = 0; i < num_rows_S_new; ++i) free(rows_S_Fi[i]);
    free(rows_S_Fi);
    free(num_rows_S_Fi);
    
    for (i = 0; i < num_rows_S_new; ++i) free(zero_indices[i]);
    free(zero_indices);
    free(num_zero_indices);
    
    return found;
}