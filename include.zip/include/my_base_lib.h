#ifndef MY_BASE_LIB_H
#define MY_BASE_LIB_H

#include <stdlib.h>
#include <stdio.h>

#define alloc(p,a,t) do \
if (!(p = (t *) malloc ((size_t) ((a) * sizeof (t))))) { \
printf("run out of memory [alloc(%s,%d,%s)]\n",#p,a,#t); \
exit(1); \
} while(0);

template <class T>
bool is_equal(T * array1,T * array2, const int length);

template <class T>
int index_in_collection(T ** collection,T * vect, const int length_collection, const int length_vect);

template <class T>
bool is_all_ones(T * pt, const int length);

template <class T>
bool is_in_array(T * array, T val, const int length);

template <class T>
std::vector<T> factor(T n);

void my_matrix_prod(int ** M, int * x, int * y, const int num_rows, const int num_cols);

void my_inner_prod(int * x, int * y, int & out, const int length);

int my_pow(int x, unsigned int p);

void generate_id_matrix(const int k,int ** Id);

void hash2size(const int S_hash,int & num_rows,int & num_cols, const int D);

#endif