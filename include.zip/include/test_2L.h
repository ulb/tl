#ifndef TEST_2L_H
#define TEST_2L_H

void canonicize(int ** S,const int num_rows,const int num_cols, const int n, const int m, setword * cg_vec);

bool is_listed(setword ** list_2L,int * list_hash,const int list_length,setword * canonical_S,const int hash_S,const int length_canonical_S);

bool istwolevelpolytope(int ** S_new,const int num_rows_S_new,const int num_cols_S_new,int * atoms_hash,setword ** atoms_cg,const int n_atoms,const int D);


#endif