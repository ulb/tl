#ifndef MATRIX_OPS
#define MATRIX_OPS


bool checksimplicialcore(int ** S, const int D);
void extractM(int ** S, int ** M, const int D);
void invertM(int ** M, int ** Minv, const int D);


void construct_slack_matrix(int **& base_H,int **& ground_set_H,int *& A,int *& B,int **& slabs,int **& S,int **& S_new,const int size_ground_H, const int num_slabs,const int length_A,const int length_B,const int num_rows_S,const int num_cols_S, int & num_rows_S_new, int & num_cols_S_new,const int D);


#endif