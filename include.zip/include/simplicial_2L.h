#ifndef SIMPLICIAL_2L_H
#define SIMPLICIAL_2L_H

void slack_matrix_free_sum(int ** P,int ** Q,const int m1,const int n1,const int m2,const int n2,int **& P_oplus_Q,int & num_rows,int & num_cols);

void slack_matrix_simplicial_2L(const int h, const int n, int **& M, int & num_r_M, int & num_c_M);

void push_simplicial_core(int **& M,const int num_rows_M,const int num_cols_M,int **& Id,const int D);

#endif