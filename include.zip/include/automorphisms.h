#ifndef AUTOMORPHISMS_H
#define AUTOMORPHISMS_H

static void my_groupelts(levelrec *lr, int n, int level, void (*action)(int*,int,std::vector<std::vector<int> >&,int &),int *before, int *after, int *id,std::vector<std::vector<int> >& automorphism_base, int & num_tot);

void my_allgroup(grouprec *grp, void (*action)(int*,int,std::vector<std::vector<int> >&,int &),std::vector<std::vector<int> >& automorphism_base, int & num_tot);

void writeautom(int *p, int n,std::vector<std::vector<int> >& automorphism_base, int & num_tot);

void construct_automorphism_base(int ** S,const int num_rows,const int num_cols, const int n, const int m, std::vector<std::vector<int> >& automorphism_base, int & num_autom_base);




#endif