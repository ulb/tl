#ifndef TO_LIST_TESTS_H
#define TO_LIST_TESTS_H

bool is_susp(int ** S_new,int num_rows_S_new,int num_cols_S_new);
void is_polar(int ** S_new,int hash_S_new, setword * canonical_S_new, int num_rows_S_new,int num_cols_S_new,const int n, const int m,int * LD_hash,setword ** LD,int current_LD,const int D,int & n_polar);

void to_list(int **& S_new,int & num_rows_S_new,int & num_cols_S_new,FILE * my_outputfile,int *& LD_hash,setword **& LD,int & current_LD, const int D, int & verbose,int & simplicial_facet,int & cs,int & stab,int & n_suspensions,int & n_polar);


#endif