#include <vector>
#include <cstring> // std::equal
#include <algorithm> // std::find

// check equality of T * arrays
template <class T>
bool is_equal(T * array1,T * array2, const int length) {
    for (int i = 0; i < length; ++i) if (array1[i] != array2[i]) return false;
    return true;
}

template <class T>
int index_in_collection(T ** collection,T * vect, const int length_collection, const int length_vect) {
    for (int i = 0; i < length_collection; ++i) if (is_equal(collection[i],vect,length_vect)) return i;
    return length_collection;
}

template <class T>
bool is_all_ones(T * pt, const int length) {
    T* end = pt + length;
    while (pt != end) {
        if (*pt == 0) return false;
        ++pt;
    }
    return true;
}

// check if val occurs in array
template <class T>
bool is_in_array(T * array, T val, const int length) {
    return std::find(array,array+length,val) != array+length;
}

// factor an integer
template <class T>
std::vector<T> factor(T n) {
    std::vector<T> factors;   
    for (T d = 1; d <= n; ++d) if (n % d == 0) factors.push_back(d);
    return factors;
}

// y = Mx
void my_matrix_prod(int ** M, int * x, int * y, const int num_rows, const int num_cols) {
    int i, j;
    for (i = 0; i < num_rows; ++i) {
        y[i] = 0;
        for (j = 0; j < num_cols; ++j) y[i] += M[i][j]*x[j];
    }
}

// <x,y> = out
void my_inner_prod(int * x, int * y, int & out, const int length) {
    out = 0;
    for (int i = 0; i < length; ++i) out += x[i]*y[i];
}

// compute the power of an int, x base, p exponent
int my_pow(int x, unsigned int p) {
    int tot = 1;
    for (int i = 1; i <= p; ++i) tot *= x;
    return tot;
}

void generate_id_matrix(const int k,int ** Id) {
    int i;
    for (i = 0; i < k; ++i) {
        std::memset(Id[i],0,i * sizeof(int));
        Id[i][i] = 1;
        std::memset(Id[i]+i+1,0,(k-i-1) * sizeof(int));
    }
}

void hash2size(const int S_hash,int & num_rows,int & num_cols, const int D) {
    num_rows = 1 + (((1 << D) - 1) & S_hash);
    num_cols = 1 + (((1 << D) - 1) & (S_hash >> D));
}

